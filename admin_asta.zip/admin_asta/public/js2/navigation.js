(function() {

  $(function() {
    return $(".profile-menu-nav-collapse .button").click(function() {
      return $(".secondary-nav-menu").toggleClass("open");
    });
  });

}).call(this);
