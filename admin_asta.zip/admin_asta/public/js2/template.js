(function() {

  _.templateSettings = {
    interpolate: /\{\{(.+?)\}\}/g
  };

}).call(this);
