(function() {

  $(function() {
    return $(".search-button-trigger").click(function() {
      return $(".search-bar-nav").toggleClass("open");
    });
  });

}).call(this);
