<div class="row no-gutters h-100">
    <div class="col">
        <div class="row no-gutters h-100 menu w-100" align="center" style="padding-left:30%; padding-right:30%;">
            <div class="col">
                <a href="" style="color:black; font-weight:bold; font-size: 100%;"><div class="asta-poker {{ Request::is('Game-Asta-Poker/Table/*') ? 'asta-poker active' : null }}"></div>Asta Poker</a>
            </div>
            <div class="col">
                <a href="" style="color:black; font-weight:bold; font-size: 100%;"><div class="asta-big"></div>Asta Big 2</a>
            </div>
            <div class="col">
                <a href="" style="color:black; font-weight:bold; font-size: 100%;"><div class="domino-susun"></div>Domino Susun</a>
            </div>
            <div class="col">
                <a href="" style="color:black; font-weight:bold; font-size: 100%;"><div class="domino-qq"></div>Domino QQ</a>
            </div>
        </div>
    </div>
</div>