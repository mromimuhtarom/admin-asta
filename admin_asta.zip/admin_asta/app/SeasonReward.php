<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class SeasonReward extends Model
{
    protected $guarded = [];
    protected $table = 'season_reward';

    public $timestamps = false;
}
