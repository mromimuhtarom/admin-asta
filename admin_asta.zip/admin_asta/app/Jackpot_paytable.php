<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Jackpot_paytable extends Model
{
    protected $table = 'jackpot_paytable';

    public $timestamps = false;
    protected $guarded = [];
}
