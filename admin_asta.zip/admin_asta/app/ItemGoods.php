<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ItemGoods extends Model
{
    protected $table = 'item_good';
    protected $guarded = [];
    public $timestamps = false;
}
