<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class SlideBanner extends Model
{
    protected $table = 'slide_banner';
    protected $guarded = [];

    public $timestamps = false;
}
