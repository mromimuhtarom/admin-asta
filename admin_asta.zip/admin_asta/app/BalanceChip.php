<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class BalanceChip extends Model
{
    protected $table = 'balance_chip';

    public $timestamps = false;
}
