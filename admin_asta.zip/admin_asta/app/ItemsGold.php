<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ItemsGold extends Model
{
    protected $table = 'items_gold';
    protected $guarded = [];
    public $timestamps = false;
}
