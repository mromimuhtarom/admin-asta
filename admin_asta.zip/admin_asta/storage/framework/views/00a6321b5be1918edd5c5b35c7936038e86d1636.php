<?php $__env->startSection('page'); ?>
<li><span id="refresh" class="btn sa-ribbon-btn sa-theme-btn" data-action="resetWidgets"><i class="fa fa-refresh"></i></span></li>
<li class="breadcrumb-item"><a href="<?php echo e(route('PaymentStore-view')); ?>">Store</a></li>
        <li class="breadcrumb-item"><a href="<?php echo e(route('PaymentStore-view')); ?>">Payment Store</a></li>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>

<?php if(count($errors) > 0): ?>
  <div class="error-val">
    <div class="alert alert-danger">
      <ul>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <li><?php echo e($error); ?></li>  
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </ul>
    </div>
  </div>
<?php endif; ?>
  
<?php if(\Session::has('success')): ?>
  <div class="alert alert-success">
    <p><?php echo e(\Session::get('success')); ?></p>
  </div>
<?php endif; ?>

<!-- Table -->
<div class="jarviswidget jarviswidget-color-blue-dark no-padding" id="wid-id-18" data-widget-colorbutton="false" data-widget-editbutton="false">

  <header>
    <div class="widget-header">	
      <h2><strong>Payment Store</strong></h2>				
    </div>
  </header>

  <div>
    <div class="widget-body">
      <div class="widget-body-toolbar">
        
        <div class="row">
          
          <!-- Button tambah chip store baru -->
          <div class="col-9 col-sm-5 col-md-5 col-lg-5">
            <div class="input-group">
              <?php if($menu): ?>
              <button class="btn sa-btn-primary" data-toggle="modal" data-target="#createPaymentStore">
                <i class="fa fa-plus"></i>
              </button>
              <?php endif; ?>
            </div>
          </div>
          <!-- End Button tambah chip store baru -->

        </div>

      </div>
      
      <div class="custom-scroll table-responsive" style="max-height:600px;">
        
        <div class="table-outer">
          <table class="table table-bordered">
            <thead>
              <tr>
                <?php if($menu): ?>
                  <th class="th-sm"></th>
                <?php endif; ?>
                <th class="th-sm">Name</th>
                <th class="th-sm">Payment Type</th>
                <th class="th-sm">Transaction Type</th>
                <th class="th-sm">image</th>
                <th class="th-sm">status</th>
                <?php if($menu): ?>
                  <th>Action</th>
                <?php endif; ?>
              </tr>
            </thead>
            <tbody>
              <?php $__currentLoopData = $getPayments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <?php if($menu): ?>
              <tr>
                <td style="text-align:center;"><input type="checkbox" name="deletepermission" class="deletepermission<?php echo e($payment->id); ?>"></td>
                <td><a href="#" class="usertext" data-title="Name" data-name="name" data-pk="<?php echo e($payment->id); ?>" data-type="text" data-url="<?php echo e(route('PaymentStore-update')); ?>"><?php echo e($payment->name); ?></td>
                <td><a href="#" class="usertext" data-title="Payment Type" data-name="payment_type" data-pk="<?php echo e($payment->id); ?>" data-type="text" data-url="<?php echo e(route('PaymentStore-update')); ?>"><?php echo e($payment->payment_type); ?></td>
                <td><a href="#" class="usertext" data-title="Transaction Type" data-name="transaction_type" data-pk="<?php echo e($payment->id); ?>" data-type="text" data-url="<?php echo e(route('PaymentStore-update')); ?>"><?php echo e(strTypeTransaction($payment->transaction_type)); ?></td>
                <td><a href="#" class="usertext" data-title="Image" data-name="image" data-pk="<?php echo e($payment->id); ?>" data-type="text" data-url="<?php echo e(route('PaymentStore-update')); ?>"><?php echo e($payment->image); ?></td>
                <td><a href="#" class="stractive" data-title="Status" data-name="status" data-pk="<?php echo e($payment->id); ?>" data-type="select" data-url="<?php echo e(route('PaymentStore-update')); ?>"><?php echo e(strEnabledDisabled($payment->status)); ?></td>
                <td style="text-align:center;">
                  <a href="#" style="color:red;" class="delete<?php echo e($payment->id); ?>" 
                    id="delete" 
                    data-pk="<?php echo e($payment->id); ?>" 
                    data-toggle="modal" 
                    data-target="#delete-modal">
                    <i class="fa fa-times"></i>
                  </a>
                </td>
              </tr>
              <?php else: ?> 
              <tr>
                <td><?php echo e($payment->name); ?></td>
                <td><?php echo e($payment->payment_type); ?></td>
                <td><?php echo e(strTypeTransaction($payment->transaction_type)); ?></td>
                <td><?php echo e($payment->image); ?></td>
                <td><?php echo e(strEnabledDisabled($payment->status)); ?></td>
              </tr>
              <?php endif; ?>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
          </table>
        </div>
      
      </div>
    
    </div>
  </div>
</div>
<!-- end Table -->

<!-- Modal -->
<div class="modal fade" id="createPaymentStore" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title" id="myModalLabel">Create New Payment Store</h4>
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">
          ×
        </button>
      </div>
      <form action="<?php echo e(route('PaymentStore-create')); ?>" method="post">
        <?php echo csrf_field(); ?>
        <div class="modal-body">
          <div class="form-group">
            <input type="text" name="title" class="form-control" id="basic-url" placeholder="title">
          </div>
          <div class="form-group">
            <input type="text" name="paymentType" class="form-control" id="basic-url" placeholder="payment type">
          </div>
          <div class="form-group">
            <select class="custom-select" name="transactionType">
              <option selected>Transaction type</option>
              <option value="1">Bank Transfer</option>
              <option value="2">Internet Banking</option>
              <option value="3">Cash Digital</option>
              <option value="4">Toko</option>
              <option value="5">Akulaku</option>
              <option value="6">Credit Card</option>
              <option value="7">Manual Transfer</option>
              <option value="8">Google Play</option>
            </select>
          </div>
        </div>
        <div class="modal-footer">
          <button type="submit" class="btn btn-default" data-dismiss="modal">
            Cancel
          </button>
          <button type="submit" class="btn sa-btn-primary">
            Save
          </button>
        </div>
      </form>
    </div>
  </div>
</div>
<!-- end Modal -->

<!-- delete Modal -->
<div class="modal fade" id="delete-modal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Delete Data</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          × 
        </button>
      </div>
      <div class="modal-body">
        Are You Sure Want To Delete It
        <form action="<?php echo e(route('PaymentStore-delete')); ?>" method="post">
          <?php echo e(method_field('delete')); ?>

          <?php echo e(csrf_field()); ?>

          <input type="hidden" name="userid" id="userid" value="">
      </div>
      <div class="modal-footer">
        <button type="submit" class="button_example-yes">Yes</button>
        <button type="button" class="button_example-no" data-dismiss="modal">No</button>
      </div>
        </form>
    </div>
  </div>
</div>
<!-- End delete Modal -->

<!-- script -->
<script>
  $(document).ready(function() {
    $('table.table').dataTable( {
      "lengthMenu": [[20, 25, 50, -1], [20, 25, 50, "All"]],
    });
  });

  table = $('table.table').dataTable({
    "sDom": "t"+"<'dt-toolbar-footer d-flex test'>",
    "autoWidth" : true,
    "paging": false,
    "classes": {
      "sWrapper": "dataTables_wrapper dt-bootstrap4"
    },
    "oLanguage": {
      "sSearch": '<span class="input-group-addon"><i class="fa fa-search"></i></span>'
    },
    "fnRowCallback": function (nRow, aData, iDisplayIndex, iDisplayIndexFull) {
      $.ajaxSetup({
        headers: {
        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
      });

      $('.usertext').editable({
        mode :'inline'
      });

      $('.stractive').editable({
        value: '',
        mode :'inline',
				source: [
                  {value: '', text: 'choose for activation'},
				          {value: '1', text: 'Enabled'},
					        {value: '0', text: 'Disabled'},
        ]
      });

      // delete Payment store
      <?php
        foreach($getPayments as $payment) {
          echo'$(".delete'.$payment->id.'").hide();';
          echo'$(".deletepermission'.$payment->id.'").on("click", function() {';
            echo 'if($( ".deletepermission'.$payment->id.':checked" ).length > 0)';
            echo '{';
              echo '$(".delete'.$payment->id.'").show();';
            echo'}';
            echo'else';
            echo'{';
              echo'$(".delete'.$payment->id.'").hide();';
            echo'}';

          echo '});';
        
          echo'$(".delete'.$payment->id.'").click(function(e) {';
            echo'e.preventDefault();';

            echo"var id = $(this).attr('data-pk');";
            echo'var test = $("#userid").val(id);';
          echo'});';
        }
      ?>
    },
    responsive: true
  });
</script>
<!-- end script -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\latihan\admin_asta\resources\views/pages/store/payment_store.blade.php ENDPATH**/ ?>