<?php $__env->startSection('page'); ?>
<li><span id="refresh" class="btn sa-ribbon-btn sa-theme-btn" data-action="resetWidgets"><i class="fa fa-refresh"></i></span></li>
<li class="breadcrumb-item"><a href="<?php echo e(route('profile-view')); ?>">Profile</a></li>
        <li class="breadcrumb-item"><a href="<?php echo e(route('profile-view')); ?>">My Account</a></li>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
<link rel="stylesheet" href="/css/admin.css">

<?php if(count($errors) > 0): ?>
  <div class="error-val">
    <div class="alert alert-danger">
      <ul>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <li><?php echo e($error); ?></li>  
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </ul>
    </div>  
  </div>
<?php endif; ?>


<?php if(\Session::has('alert')): ?>
<div class="alert alert-danger">
    <div><?php echo e(Session::get('alert')); ?></div>
</div>
    
<?php endif; ?>

  
<?php if(\Session::has('success')): ?>
  <div class="alert alert-success">
    <p><?php echo e(\Session::get('success')); ?></p>
  </div>
<?php endif; ?>



<div class="profile bg-blue-dark">
    <div class="table-header w-100 h-100" style="padding-right:2%;">
        <form action="" method="post">
            <table style="color:white" border="1" width="100%" height="100%">
                <tr>
                    <td colspan="3" align="center" style="font-size: 200%;">My Profile</td>
                </tr>
                <tr>
                    <td>Username</td>
                    <td align="center"> :</td>
                    <td><?php echo e($profile->username); ?></td>
                </tr>
                <tr>
                    <td>Role</td>
                    <td align="center">:</td>
                    <td><?php echo e($profile->rolename); ?></td>
                </tr>
                <tr>
                    <td>Full Name</td>
                    <td align="center">:</td>
                    <td><a href="#" class="usertext" data-name="fullname" data-title="Full Name" data-pk="<?php echo e($profile->operator_id); ?>" data-type="text" data-url="<?php echo e(route('profile-update')); ?>"><?php echo e($profile->fullname); ?></a></td>
                </tr>
                <tr>
                    <td>Password</td>
                    <td align="center">:</td>
                    <td><a href="#" class="password btn btn-primary" id="password" data-pk="<?php echo e($profile->operator_id); ?>" data-toggle="modal" data-target="#reset-password">Reset Password</a></td>
                </tr>
            </table>
        </form>
    </div>
</div>


  
  <div class="modal fade" id="reset-password" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel">Reset Password</h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            × 
          </button>
        </div>
        <div class="modal-body">
          <form action="<?php echo e(route('profile-password')); ?>" method="post">
            <?php echo e(csrf_field()); ?>

            <input type="hidden" name="userid" id="userid" value="">
            <input type="password" class="form-control" name="password" placeholder="Password" value="" required/>
        </div>
        <div class="modal-footer">
          <button type="submit" class="button_example-yes">Reset Password</button>
          <button type="button" class="button_example-no" data-dismiss="modal">No</button>
        </div>
          </form>
      </div>
    </div>
  </div>



<script type="text/javascript">
    $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });
        // $.fn.editable.defaults.mode = 'inline';


    $('.usertext').editable({
      mode: 'inline'
    });
  </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\latihan\admin_asta\resources\views/pages/profile/user_profile.blade.php ENDPATH**/ ?>