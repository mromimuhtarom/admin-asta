<?php $__env->startSection('page'); ?>
<li><span id="refresh" class="btn sa-ribbon-btn sa-theme-btn" data-action="resetWidgets"><i class="fa fa-refresh"></i></span></li>
<li class="breadcrumb-item"><a href="<?php echo e(route('GeneralSetting-view')); ?>">Settings</a></li>
        <li class="breadcrumb-item"><a href="<?php echo e(route('GeneralSetting-view')); ?>">General Setting</a></li>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>

<div class="settings-table">
  <div>
    <div class="jarviswidget jarviswidget-color-blue-dark no-padding" id="wid-id-18" data-widget-colorbutton="false" data-widget-editbutton="false">
      
      <header>
        <div class="widget-header">	
          <h2><strong>System Settings</strong></h2>				
        </div>
      </header>
    
      <div>
        <div class="widget-body">
          <div class="custom-scroll table-responsive">
            
            <div class="table-outer">
              <table class="table table-bordered">
                <thead>
                  <tr>
                    <th class="th-sm">Name</th>
                    <th class="th-sm">Setting</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td>Maintenance</td>
                    <?php if($menu): ?>
                    <td>
                      <a href="#" class="popUpSetting" data-title="Maintenance" data-name="value" data-value="<?php echo e($getMaintenance->value); ?>" data-pk="<?php echo e($getMaintenance->id); ?>" data-type="select" data-url="<?php echo e(route('GeneralSetting-update')); ?>">
                        <?php if($getMaintenance->value == 1): ?>
                          On
                        <?php else: ?>
                          Off
                        <?php endif; ?>
                      </a>
                    </td>
                    <?php else: ?> 
                    <td>
                      <?php if($getMaintenance->value == 1): ?>
                        On
                      <?php else: ?>
                        Off
                      <?php endif; ?>
                    </td>
                    <?php endif; ?>
                  </tr>
                  <tr>
                    <td>Point Expired</td>
                    <?php if($menu): ?>
                    <td>
                      <a href="#" class="inlineSetting" data-title="Point Expired" data-name="value" data-pk="<?php echo e($getPointExpired->id); ?>" data-type="number" data-url="<?php echo e(route('GeneralSetting-update')); ?>"><?php echo e($getPointExpired->value); ?></a><span> (hari)</span>
                    </td>
                    <?php else: ?>
                    <td><?php echo e($getPointExpired->value); ?> (hari)</td>
                    <?php endif; ?>
                  </tr>
                </tbody>
              </table>
            </div>
        
          </div>
        
        </div>
      </div>
    </div>
  </div>

  <div>
    <div class="jarviswidget jarviswidget-color-blue-dark no-padding" id="wid-id-18" data-widget-colorbutton="false" data-widget-editbutton="false">
      
      <header>
        <div class="widget-header">	
          <h2><strong>Bank Settings</strong></h2>				
        </div>
      </header>
    
      <div>
        <div class="widget-body">
          <div class="custom-scroll table-responsive">
            
            <div class="table-outer">
              <table class="table table-bordered">
                <thead>
                  <tr>
                    <th class="th-sm">Name</th>
                    <th class="th-sm">Value</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td>BCA</td>
                    <?php if($menu): ?>
                    <td>
                      <a href="#" class="inlineSetting" data-title="Twitter" data-name="value" data-pk="<?php echo e($getBank->id); ?>" data-type="text" data-url="<?php echo e(route('GeneralSetting-update')); ?>"><?php echo e($getBank->value); ?></a>
                    </td>
                    <?php else: ?> 
                    <td><?php echo e($getBank->value); ?></td>
                    <?php endif; ?>
                  </tr>
                </tbody>
              </table>
            </div>
          
          </div>
        
        </div>
      </div>
    </div>
  </div>

  <div>
    <div class="jarviswidget jarviswidget-color-blue-dark no-padding" id="wid-id-18" data-widget-colorbutton="false" data-widget-editbutton="false">
      
      <header>
        <div class="widget-header">	
          <h2><strong>Info Settings</strong></h2>				
        </div>
      </header>
    
      <div>
        <div class="widget-body">
          <div class="custom-scroll table-responsive">
            
            <div class="table-outer">
              <table class="table table-bordered">
                <thead>
                  <tr>
                    <th class="th-sm">Name</th>
                    <th class="th-sm">Setting</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td>Privacy Policy</td>
                    <?php if($menu): ?>
                    <td><a href="#" class="inlineSetting" data-title="Facebook" data-name="value" data-pk="<?php echo e($getPrivacyPolicy->id); ?>" data-type="text" data-url="<?php echo e(route('GeneralSetting-update')); ?>"><?php echo e($getPrivacyPolicy->value); ?></a></td>
                    <?php else: ?> 
                    <td><?php echo e($getPrivacyPolicy->value); ?></td>
                    <?php endif; ?>
                  </tr>
                  <tr>
                    <td>Term Of Service</td>
                    <?php if($menu): ?>
                    <td><a href="#" class="inlineSetting" data-title="Term Of Service" data-name="value" data-pk="<?php echo e($getTermOfService->id); ?>" data-type="text" data-url="<?php echo e(route('GeneralSetting-update')); ?>"><?php echo e($getTermOfService->value); ?></a></td>
                    <?php else: ?> 
                    <td><?php echo e($getTermOfService->value); ?></td>
                    <?php endif; ?>
                  </tr>
                  <tr>
                    <td>Term Of Service</td>
                    <?php if($menu): ?>
                    <td><a href="#" class="inlineSetting" data-title="About" data-name="value" data-pk="<?php echo e($getAbout->id); ?>" data-type="text" data-url="<?php echo e(route('GeneralSetting-update')); ?>"><?php echo e($getAbout->value); ?></a></td>
                    <?php else: ?> 
                    <td><?php echo e($getAbout->value); ?></td>
                    <?php endif; ?>
                  </tr>
                  <tr>
                    <td>PokerWeb</td>
                    <?php if($menu): ?>
                    <td><a href="#" class="inlineSetting" data-title="About" data-name="value" data-pk="<?php echo e($getPokerWeb->id); ?>" data-type="text" data-url="<?php echo e(route('GeneralSetting-update')); ?>"><?php echo e($getPokerWeb->value); ?></a></td>
                    <?php else: ?> 
                    <td><?php echo e($getPokerWeb->value); ?></td>
                    <?php endif; ?>
                  </tr>
                </tbody>
              </table>
            </div>
          
          </div>
        
        </div>
      </div>
    </div>
  </div>

  <div>
    <div class="jarviswidget jarviswidget-color-blue-dark no-padding" id="wid-id-18" data-widget-colorbutton="false" data-widget-editbutton="false">
      <header>
        <div class="widget-header">	
          <h2><strong>CS & Legal Settings</strong></h2>				
        </div>
      </header>
    
      <div>
        <div class="widget-body">
          <div class="custom-scroll table-responsive">
            
            <div class="table-outer">
              <table class="table table-bordered">
                <thead>
                  <tr>
                    <th class="th-sm">Name</th>
                    <th class="th-sm">Setting</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td>Facebook</td>
                    <?php if($menu): ?>
                    <td><a href="#" class="inlineSetting" data-title="Facebook" data-name="value" data-pk="<?php echo e($getFb->id); ?>" data-type="text" data-url="<?php echo e(route('GeneralSetting-update')); ?>"><?php echo e($getFb->value); ?></a></td>
                    <?php else: ?> 
                    <td><?php echo e($getFb->value); ?></td>
                    <?php endif; ?>
                  </tr>
                  <tr>
                    <td>Twitter</td>
                    <?php if($menu): ?>
                    <td><a href="#" class="inlineSetting" data-title="Twitter" data-name="value" data-pk="<?php echo e($getTwitter->id); ?>" data-type="text" data-url="<?php echo e(route('GeneralSetting-update')); ?>"><?php echo e($getTwitter->value); ?></a></td>
                    <?php else: ?> 
                    <td><?php echo e($getTwitter->value); ?></td>
                    <?php endif; ?>
                  </tr>
                  <tr>
                    <td>Instagram</td>
                    <?php if($menu): ?>
                    <td><a href="#" class="inlineSetting" data-title="Instagram" data-name="value" data-pk="<?php echo e($getIg->id); ?>" data-type="text" data-url="<?php echo e(route('GeneralSetting-update')); ?>"><?php echo e($getIg->value); ?></a></td>
                    <?php else: ?> 
                    <td><?php echo e($getIg->value); ?></td>
                    <?php endif; ?>
                  </tr>
                </tbody>
              </table>
            </div>
          
          </div>
        
        </div>
      </div>
    </div>
  </div>
  
</div>


<script>
  $(document).ready(function() {
    $('table.table').dataTable( {
      "lengthMenu": [[5, 10, 20, -1], [5, 10, 20, "All"]],
    });
  });

  table = $('table.table').dataTable({
    "sDom": "t"+"<'dt-toolbar-footer d-flex test'>",
    "autoWidth" : true,
    "paging": false,
    "classes": {
      "sWrapper": "dataTables_wrapper dt-bootstrap4"
    },
    "oLanguage": {
      "sSearch": '<span class="input-group-addon"><i class="fa fa-search"></i></span>'
    },
    "fnRowCallback": function (nRow, aData, iDisplayIndex, iDisplayIndexFull) {
      $.ajaxSetup({
        headers: {
        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
      });

      $('.inlineSetting').editable({
            mode :'inline'
        });

      $('.popUpSetting').editable({
        mode: 'inline',
        value: 0,
        source: [
          {value: 0, text: 'Off'},
          {value: 1, text: 'On'}
        ]
      });
     
    },
    responsive: true
  });

</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\latihan\admin_asta\resources\views/pages/settings/general_setting.blade.php ENDPATH**/ ?>